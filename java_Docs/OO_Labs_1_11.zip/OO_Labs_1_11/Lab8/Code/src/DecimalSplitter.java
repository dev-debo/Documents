public class DecimalSplitter {
	static boolean isOdd(int num) {
//Complete the logic
	}
	static int getWhole(double num) {
//Complete the logic
	}
	
	static double getFraction(double num) {
//Complete the logic
	}
}









