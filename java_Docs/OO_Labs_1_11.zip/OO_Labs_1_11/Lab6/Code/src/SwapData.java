public class SwapData {
	private int arg1;
	private int arg2;

	public void swapValues() {

	//Logic to swap values
	
	}

	public void displayValues(String str) {

	//Display string message with values of arg1 and arg2

	}

// Create setter and getter methods 

}
