public class Address {


//	Complete the code by creating variables and methods


}
