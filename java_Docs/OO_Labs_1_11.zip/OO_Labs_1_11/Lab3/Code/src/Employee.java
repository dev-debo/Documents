public class Employee {

// Identity variables and methods. Create association with Address

}
