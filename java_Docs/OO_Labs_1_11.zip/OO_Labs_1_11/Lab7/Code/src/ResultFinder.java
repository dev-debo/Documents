public class ResultFinder {
	private int m1;
	private int m2;
	private int m3;
	
	// Create setter and getter methods 

	public void displayMarks() {


	
	}
	public int getTotal() {
//		complete the logic
	}
	public double getAverage() {
//		complete the logic
	}
	
	public String getResult() {

//		complete the logic

	}
}
