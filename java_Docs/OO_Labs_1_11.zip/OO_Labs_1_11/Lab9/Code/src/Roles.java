public class Roles {

	// Declare necessary data members
}