public class Employee {
	
	// Identity variables of Employee 
	
	// Create getter and setter methods

	
}




















